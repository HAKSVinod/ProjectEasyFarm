<!DOCTYPE html>
<html>
<head>
	<title>Delete Fertilizer</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="../css/styles.css">
</head>
<body>
	<div class="form">

				<b><h4>
				<form method="post" action="../model/deletefertilizer.php">
			
				<table border="0"  width="700px">
				
				
				<tr><td height="50px" colspan="3"></td></tr>	
				<tr >
					<td >Fertilizer ID</td>
					
					<td ><input type="integer" name="Fertilizer_ID" size="30" maxlength="15" ></td>
				
					<td><center><input type="Submit" name="bfertilizer" value="Delete"></center></td>
				</tr>
				</table>
			
				</form>
				</h4>
				</b>
	</div>
</body>
</html>