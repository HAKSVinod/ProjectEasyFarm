<!DOCTYPE html>
<html>
<head>
	<title>Add Meetings</title>
</head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta charset="UTF-8">

<body>

	


	<div class="content">
		

		<div class="form">

				<b><h4>
				<form method="POST" action="#">
			
				<table border="0" class="table table-stripped table-hover">
				
					
				
				 
				<tr><td height="50px" colspan="3"></td></tr>
				<tr>
					<td>Date</td>
					<td width="50px"></td>
					<td ><input type="Date" name="meeting_date"></td>
				</tr>
				
				
				<tr><td height="50px" colspan="3"></td></tr>
				<tr>
					<td>Time</td>
					<td width="50px"></td>
					<td ><input type="Time" name="meeting_time"></td>
				</tr>	
				

				<tr><td height="50px" colspan="3"></td></tr>	
				<tr >
				 	<td >Purpose</td>
					<td width="50px"></td>
					<td ><textarea name=“message” rows=“10” cols=“100”>
						</textarea></td>
				</tr>				
					
				
				<tr><td height="50px" colspan="3"></td></tr>
				<tr> 
			
					<td ><center></center></td>
					<td width="50px"></td>
					<td><center><input type="Submit" name="bmeeting" value="Upload" class="btn btn-primary">   </center></td>
				</tr>
				</table>
			
				</form>
				</h4>
				</b>
	</div>
	<?php
		require "controller/connect.php";
	?>
	<?php 

			if(isset($_POST['submit'])){
			
			$Date=$_POST['date'];
			$Time = $_POST['time'];
			$Purpose = $_POST['message'];
			

		
			
			$sql="INSERT INTO `meetings`(`Date`, `Time`, `Purpose`) VALUES ('$Date','$Time','$Purpose')";

			$res=mysqli_query($conn,$sql);
			if(!$res){
			echo mysqli_error($conn);
		}
	}

	?>

	
</body>
</html>