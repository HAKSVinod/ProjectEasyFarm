<!DOCTYPE html>
<html>
<head>
	<title>View Meetings</title>
</head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="../css/styles.css">

<body>

	


	<div class="content">
		

		<div class="form">

				<b><h4>
				<form method="POST" action="#">
			
				<table border="1">
				
					
				
				 
				
				<tr>
					<th>Date</th>
					<th>Description</th>
				</tr>
				<tr>
					<td><center><input type="reset" name="reset" value="Cancel">   </center></td>
				</tr>
				</table>
			
				</form>
				</h4>
				</b>
	</div>
	

	
</body>
</html>